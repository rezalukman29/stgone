<?php

namespace App\Http\Controllers;
use App\Models\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

class DepartmentController extends Controller
{
    //

    public function index(Request $request)
    {
          
      $departments = Department::where('parent_id',0)->get();
     
      return view('admin.employee.employees.create',["departments" => $departments]);
    }    

}
