$('.progress .progress-bar').progressbar({ display_text: 'center' });
