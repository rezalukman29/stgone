<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Datatable_absent extends Model
{
    protected $table = 'absents';

    protected $guarded  = ['id'];

    
}


