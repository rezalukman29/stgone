<?php

return [

    'views' => [

        'builder' => 'generator-builder::builder',

        'field-template' => 'generator-builder::field-template'
    ]
];
